## About Laravel AirBnb

Laravel AirBnb is a web application built with laravel


## License

The Laravel AirBnb is open-sourced software licensed under the [MIT license](https://opensource.org/licenses/MIT).

## Screenshots
![first image](screenshots/one.png?raw=true "one")
![second image](screenshots/two.png?raw=true "two")
![third image](screenshots/three.png?raw=true "three")
![fourth image](screenshots/four.png?raw=true "four")
![fifth image](screenshots/five.png?raw=true "five")
![sixth image](screenshots/six.png?raw=true "six")
![seventh image](screenshots/seven.png?raw=true "seven")